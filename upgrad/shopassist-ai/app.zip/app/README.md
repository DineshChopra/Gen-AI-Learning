This is web UI interface of chatbot. For web server we are using Flask, For Large language model we are using openai LLM

We have to update **api_key** in **OpenAI_API_Key_1.txt** file

List all conda environment:
    conda env list

Activate conda environment <shopassist>
    conda activate shopassist

To Lanunch web server run below command:
    python app.py

It will launch UI at followinng url : http://127.0.0.1:5000/ 
