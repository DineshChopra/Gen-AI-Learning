from flask import Flask, render_template, redirect, url_for, request
# from functions import start_conversation, initialize_conv_reco, get_chat_model_completions, moderation_check,intent_confirmation_layer,dictionary_present,compare_laptops_with_user,recommendation_validation
from functions import start_conversation, get_chat_model_completions, intent_confirmation_layer, extract_dictionary_from_string, compare_laptop_with_user_req, recommendation_validation, initialize_conversation_for_product_recommendation

import ast
import re
import pandas as pd
import json

# openai.api_key = open("api_key.txt", "r").read().strip()

app = Flask(__name__)

conversation_bot = []
welcome_message = start_conversation()
conversation_bot.append({'bot': welcome_message})
top_3_laptops = None
print("Hello world -----")

@app.route("/")
def default_func():
    global conversation_bot, conversation, top_3_laptops
    return render_template("index.html", conversation_list = conversation_bot)

# @app.route("/")
# def default_func():
#     return render_template("index_hello.html", name_xyz = "Gupta Ji")

# @app.route("/end_conv", methods = ['POST','GET'])
# def end_conv():
#     global conversation_bot, conversation, top_3_laptops
#     conversation_bot = []
#     conversation = initialize_conversation()
#     introduction = get_chat_model_completions(conversation)
#     conversation_bot.append({'bot':introduction})
#     top_3_laptops = None
#     return redirect(url_for('default_func'))

@app.route("/converse", methods = ['POST'])
def converse():
    global conversation_bot, conversation, top_3_laptops, conversation_reco
    user_input = request.form["user_input"]

    if top_3_laptops is None:
        prompt = 'Remember your system message and that you are an intelligent laptop assistant. So, you only help with questions around laptop.'
        content = user_input + prompt
        conversation_bot.append({'user': user_input})

        response_assistant = get_chat_model_completions(content)

        confirmation = intent_confirmation_layer(response_assistant)


        print("Response Assistant : ", response_assistant)
        if "No" in confirmation:
            conversation_bot.append({'bot':response_assistant})
        else:
            response = extract_dictionary_from_string(response_assistant)

            conversation_bot.append({'bot':"Thank you for providing all the information. Kindly wait, while I fetch the products: \n"})
            print("user requirement :::: ", response)
            top_3_laptops = compare_laptop_with_user_req(response)
            print("top_3_laptops ---- ", top_3_laptops)

            validated_reco = recommendation_validation(top_3_laptops)

            if len(validated_reco) == 0:
                conversation_bot.append({'bot':"Sorry, we do not have laptops that match your requirements. Connecting you to a human expert. Please end this conversation."})

            conversation_reco = initialize_conversation_for_product_recommendation(validated_reco)
            conversation_bot.append({'bot':conversation_reco})
    print("redirect to home page -------")
    return redirect(url_for('default_func'))

if __name__ == '__main__':
    app.run(debug=True, host= "0.0.0.0", port="5000")