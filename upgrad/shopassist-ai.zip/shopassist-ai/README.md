![Alt text](ievaluation.png)

 - [System Design](./ShopAssist-System%20Design.pdf)
 - [Technical Implementation](./notebook/shopassist_ai.ipynb)
 - [User Experience](./app/README.md)
 - [Project Documentation](./Shopassist-Documentation.pdf)


